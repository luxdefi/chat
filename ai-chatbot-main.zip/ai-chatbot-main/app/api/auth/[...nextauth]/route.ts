export { GET, POST } from '@/auth'
export const runtime = 'edge'
